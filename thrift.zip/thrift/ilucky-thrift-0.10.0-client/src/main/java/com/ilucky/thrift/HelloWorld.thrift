namespace java com.ilucky.thrift
 
service  HelloWorldService {
  string sayHello(1:string username)
}