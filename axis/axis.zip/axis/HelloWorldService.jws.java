
public class HelloWorldService {

    public String sayHello(String name, int age) {
        return name + " say : hello world! [axis] my age is " + age;
    }
}