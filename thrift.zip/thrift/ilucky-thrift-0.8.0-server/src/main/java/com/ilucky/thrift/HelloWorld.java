package com.ilucky.thrift;

public interface HelloWorld {

	public String sayHello(String username);
}
